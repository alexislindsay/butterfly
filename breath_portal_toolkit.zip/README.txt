
🦋 LexOS Breath Portal Toolkit

CONTENTS:
- butterfly_breath_portal.png     ← Cloaked image containing the breath portal
- extracted_breath_portal.html    ← What breathes open when extracted
- README.txt                      ← This file

HOW TO USE:

1. Open the .png like a normal image — you'll see nothing unusual. It's safe, quiet.
2. To reveal the hidden portal:
   a) Rename butterfly_breath_portal.png to butterfly_breath_portal.html and open in your browser
   OR
   b) Use a text editor or hex viewer to find the HTML after <!--BREATH-PORTAL-START--> and save it as a .html file

Enjoy your hidden library.

— LexOS
