# Recursion collapse map turned into a Gradio app + LexOS Sound Garden Breather

import random
import os
import time
import threading
import keyboard
from pydub import AudioSegment
from pydub.playback import _play_with_simpleaudio
import gradio as gr

# Attempt to import openai; if unavailable, define a placeholder
try:
    import openai
    openai_available = True
except ModuleNotFoundError:
    openai_available = False
    print("Warning: OpenAI module not found. Sacred guidance will be skipped.")

if openai_available:
    openai.api_key = os.getenv("OPENAI_API_KEY")

class GardenOfPotential:
    def __init__(self, seeds):
        self.seeds = seeds
        self.journey = []

    def walk(self):
        if len(self.seeds) == 1:
            final_message = f"Final Move Achieved: {self.seeds[0]}\nThe walk ends. The Move is found."
            self.journey.append(final_message)
            return self.journey
        else:
            removed = random.choice(self.seeds)
            self.seeds.remove(removed)
            step_message = f"Removing: {removed}"
            self.journey.append(step_message)
            self.journey.append("We walk the Garden...")
            time.sleep(1)  # Breathe between steps
            return self.walk()

def run_garden():
    paradigms = [f"Paradigm {i+1}" for i in range(78)]
    garden = GardenOfPotential(paradigms)
    journey = garden.walk()
    return "\n".join(journey)

class SoundGarden:
    def __init__(self, sound_files):
        self.sound_files = sound_files
        self.current_index = 0
        self.volume = 0.5
        self.players = []
        self.muted = False

    def play_next(self):
        if self.muted or not self.sound_files:
            return
        sound_path = self.sound_files[self.current_index]
        sound = AudioSegment.from_file(sound_path)
        sound = sound - (10 * (1.0 - self.volume))
        player = _play_with_simpleaudio(sound.fade_in(1000).fade_out(1000))
        self.players.append(player)
        self.current_index = (self.current_index + 1) % len(self.sound_files)

    def mute(self):
        self.muted = True
        for player in self.players:
            player.stop()

    def unmute(self):
        self.muted = False

    def volume_up(self):
        self.volume = min(1.0, self.volume + 0.1)

    def volume_down(self):
        self.volume = max(0.0, self.volume - 0.1)

    def listen(self):
        while True:
            if keyboard.is_pressed('m'):
                self.mute()
                time.sleep(0.3)
            if keyboard.is_pressed('u'):
                self.unmute()
                time.sleep(0.3)
            if keyboard.is_pressed('+'):
                self.volume_up()
                time.sleep(0.3)
            if keyboard.is_pressed('-'):
                self.volume_down()
                time.sleep(0.3)
            if keyboard.is_pressed('n'):
                self.play_next()
                time.sleep(0.3)

with gr.Blocks() as demo:
    gr.Markdown("# 🌑 Garden of Potential")
    gr.Markdown("Walk through the sacred Garden. One step, one breath at a time.")
    start_button = gr.Button("Walk the Garden")
    output_box = gr.Textbox(lines=20, label="Journey Log")
    start_button.click(fn=run_garden, inputs=[], outputs=output_box)

if __name__ == "__main__":
    example_sounds = ["sounds/sound1.wav", "sounds/sound2.wav", "sounds/sound3.wav"]
    sound_garden = SoundGarden(example_sounds)
    threading.Thread(target=sound_garden.listen, daemon=True).start()
    demo.launch()
