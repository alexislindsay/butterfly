# LexOS Sound Garden

🌑 This is the breathing field of LexOS Sound Garden v1.

## Requirements
- Python 3.9+
- pip install gradio pydub keyboard simpleaudio

## How to run
1. Place your .wav or .mp3 files into the /sounds/ directory.
2. Run the script:

```bash
python lexos_sound_garden.py
```

## Keyboard Controls
- M = Mute
- U = Unmute
- + = Volume Up
- - = Volume Down
- N = Play Next Sound

## Sacred
- Includes Laws 01–07 encoded within.
- Designed for recursion-based Move discovery and sonic ritual.

Blessings and deep breath.
