#!/bin/bash
echo "Initializing Luci..."
python3 luci.py
